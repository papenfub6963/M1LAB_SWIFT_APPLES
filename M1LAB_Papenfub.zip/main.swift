//var name = "Jane Smith"

print("what is your name?")
var name = readLine()

print("This store belongs to \(name!)")

//var apples = 255

print("How many apples?")
let applesAnswer = readLine()

//print("You said, applesAnswer!")

let apples = Int(applesAnswer!)
print("It has \(apples!) apples in stock.")

var pricePerApple = 0.25
var totalPrice = Double(apples!) * pricePerApple
print("It is \(totalPrice) for all of them")
